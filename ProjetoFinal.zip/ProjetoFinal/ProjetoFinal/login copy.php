<?php
include_once "conexaoLoginUsuario.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $usuario = $_POST["usuario"];
    $senha = $_POST["senha"];

    $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT);


    $sql = "INSERT INTO usuarios (usuario, senha) VALUES ("$usuario", "$senha")";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $usuario, $senhaCriptografada);

    if ($stmt->execute()) {
        echo "Usuário cadastrado com sucesso!";
    } else {
        echo "Erro ao cadastrar usuário: " . $stmt->error;
    }
}
?>